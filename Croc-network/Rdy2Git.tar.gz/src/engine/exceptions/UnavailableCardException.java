package engine.exceptions;

public class UnavailableCardException extends Exception{ 


	/**
	 * auto-generated
	 */
	private static final long serialVersionUID = 1L;

	public UnavailableCardException(){

	    System.out.println("This card isn't available to this pirate.");

	  }  

	}