package engine.exceptions;

public class PlayerAmountException extends Exception{ 

	/**
	 * auto-generated
	 */
	private static final long serialVersionUID = 1L;

	public PlayerAmountException(){

	    System.out.println("This game can only be played by 2 to 7 players.");

	  }  

	}
