package engine.exceptions;

public class NotEveryoneChoseCardException  extends Exception{ 


	/**
	 * auto-generated
	 */
	private static final long serialVersionUID = 1L;

	public NotEveryoneChoseCardException(){

	    System.out.println("All players must choose a card for every pirates they own.");

	  }  

	}