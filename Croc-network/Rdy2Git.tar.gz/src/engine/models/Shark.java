package engine.models;
/**
 * Shark class, used for animation purpose.
 * @author sykefu
 *
 */
public class Shark {
	float x;
	float y;
	//just some coordinates, maybe add an image
	public Shark(){
		x = 0;
		y = 0;
	}
}
