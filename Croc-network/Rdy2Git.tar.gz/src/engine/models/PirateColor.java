package engine.models;
/**
 * The pirate's color.
 * @author sykefu
 *
 */
public enum PirateColor {
	WHITE, RED, GREEN, PURPLE, ORANGE, YELLOW, 
	BLACK
	//no blue because water is blue in case of animation
}
