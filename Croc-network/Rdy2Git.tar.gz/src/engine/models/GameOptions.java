package engine.models;

public class GameOptions {
	int playerAmount;
	//might want to save who have what color
	//might want to save player names
	//--> save players
}
